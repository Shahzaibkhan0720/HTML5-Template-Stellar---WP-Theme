<?php 
function stellar_supports () {

    add_theme_support('title-tag');

    add_theme_support('post-thumbnails');

	add_image_size ('home-featured', 640 , 400 , array('center', 'center'));
	add_image_size ('single-post', 580 , 272 , array('center', 'center'));

    add_theme_support('automatic-feed-links');

    register_nav_menus( array(
    'primary'   => __( 'Primary Menu', 'moderato' ),
    'secondary' => __( 'Secondary Menu', 'moderato' ), 
    ) );
}

	
add_action('after_setup_theme', 'stellar_supports');

function stellar_custom_logo_setup() {
	$defaults = array(
		'height'               => 250,
		'width'                => 150,
		'flex-height'          => false,
		'flex-width'           => false,
		'header-text'          => array( 'site-title', 'site-description' ),
		'unlink-homepage-logo' => false, 
	);
	add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'stellar_custom_logo_setup' );

function stellar_scripts(){
    wp_enqueue_style('style',get_stylesheet_uri());

    wp_enqueue_script('jquery');

    wp_enqueue_script('scrollex-js', get_template_directory_uri(). '/assets/js/jquery.scrollex.min.js');
    wp_enqueue_script('scrollly-js', get_template_directory_uri(). '/assets/js/jquery.scrolly.min.js');
    wp_enqueue_script('browser-js', get_template_directory_uri(). '/assets/js/browser.min.js');
    wp_enqueue_script('breakpoint-js', get_template_directory_uri(). '/assets/js/breakpoints.min.js');
    wp_enqueue_script('util-js', get_template_directory_uri(). '/assets/js/util.js');
    wp_enqueue_script('stellar-main-js', get_template_directory_uri(). '/assets/js/main.js');

}
add_action('wp_enqueue_scripts', 'stellar_scripts');

